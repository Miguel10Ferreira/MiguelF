import UIKit

extension CGSize {
    static func cellSize(from collectionView: UICollectionView) -> CGSize {
        let size = (collectionView.bounds.width - 60) / 2
        return CGSize(width: size, height: size)
    }
}
