import UIKit

final class TabBarController: UITabBarController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupTabbar()
    }
    
    private func setupTabbar() {
        tabBar.barTintColor = .darkGrey
        tabBar.tintColor = .yellow
        tabBar.isTranslucent = false

        let pokedexView = PokedexViewBuilder.build()
        pokedexView.tabBarItem = .pokedex(title: pokedexView.title)

        let itemsView = ListBuilder.build()
        itemsView.tabBarItem = .items(title: itemsView.title)
        setViewControllers([pokedexView, itemsView], animated: false)
    }
}
