import UIKit

final class ItemsViewController: TableViewController {

    private let viewModel: ViewModel
    
    override var preferredStatusBarStyle: UIStatusBarStyle { .lightContent }

    init(viewModel: ViewModel, tableData: UITableView.DataSource) {
        self.viewModel = viewModel
        super.init(tableData: tableData)
    }
    
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = viewModel.cleanTitle
    }
}
