import UIKit

protocol ListViewRoutable {
    func routeToItemList(with data: ItemData)
}

final class ListRouter: ListViewRoutable {
    
    weak var navigationController: UINavigationController?
    
    func routeToItemList(with data: ItemData) {
        let view = ItemsViewBuilder.build(with: data)
        navigationController?.pushViewController(view, animated: true)
    }
}
