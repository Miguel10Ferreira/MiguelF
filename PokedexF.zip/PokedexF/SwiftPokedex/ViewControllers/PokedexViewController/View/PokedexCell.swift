import UIKit

final class PokedexCell: UICollectionViewCell, ConfigurableCell {
    
    private lazy var imageView: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        imageView.alpha = 0.0
        return imageView
    }()
    
    private lazy var indexLabel: UILabel = {
        let label = UILabel(useAutolayout: true)
        label.textAlignment = .right
        label.textColor = .white
        label.font = .pixel14
        label.alpha = 0.0
        return label
    }()

    private lazy var titleLabel: UILabel = {
        let label = UILabel(useAutolayout: true)
        label.textAlignment = .center
        label.textColor = .white
        label.font = .pixel17
        label.alpha = 0.0
        return label
    }()

    override var isHighlighted: Bool { didSet { animateHighlight(isHighlighted) }}

    var data: PokemonDetails?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        backgroundColor = .darkGrey

        contentView.addSubview(imageView)
        imageView.pinToSuperview(with: UIEdgeInsets(top: 0, left: 0, bottom: 35, right: 0), edges: .all)
        
        contentView.addSubview(indexLabel)
        NSLayoutConstraint.activate([
            indexLabel.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 10.0),
            indexLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -10.0)
        ])

        contentView.addSubview(titleLabel)
        NSLayoutConstraint.activate([
            titleLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            titleLabel.topAnchor.constraint(equalTo: imageView.bottomAnchor),
            titleLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
            titleLabel.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -15.0)
        ])
        
        layer.cornerRadius = 20.0
    }
    
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        
        imageView.image = nil
    }
    
    func configure(with pokemon: PokemonDetails) {
        data = pokemon
        
        titleLabel.text = pokemon.name.capitalized
        indexLabel.text = "#\(pokemon.id)"
        
        UIImage.load(from: pokemon.sprite.url) { [weak self] image in
            let color = image?.dominantColor ?? .darkGrey
            
            DispatchQueue.main.async {
                self?.titleLabel.textColor = color.isLight ? .black : .white
                self?.indexLabel.textColor = color.isLight ? .black : .white
                self?.imageView.image = image
                self?.backgroundColor = color
                
                guard self?.imageView.alpha != 1.0 else { return }
                
                UIView.animate(withDuration: 0.2) {
                    self?.imageView.alpha = 1.0
                    self?.indexLabel.alpha = 1.0
                    self?.titleLabel.alpha = 1.0
                }
            }
        }
    }
    
    func animateHighlight(_ isHighlighted: Bool) {
        UIView.animate(withDuration: 0.1, delay: 0.0, options: .allowUserInteraction, animations: {
            let scale: CGFloat = 0.95
            self.transform = isHighlighted ? CGAffineTransform(scaleX: scale, y: scale) : .identity
        }, completion: nil)
    }
}
